from colls.models import Coll, Comment, Fav
from colls.owner import OwnerListView, OwnerDetailView, OwnerCreateView, OwnerUpdateView, OwnerDeleteView
from django.views import View
from django.shortcuts import render, redirect, get_object_or_404
from django.urls import reverse_lazy
from django.http import HttpResponse
from django.contrib.auth.mixins import LoginRequiredMixin
from django.urls import reverse

from django.core.paginator import Paginator
from django.core.paginator import EmptyPage
from django.core.paginator import PageNotAnInteger

from colls.forms import CommentForm

from django.contrib.humanize.templatetags.humanize import naturaltime

from django.db.models import Q
from colls.utils import dump_queries


class CollListView(OwnerListView):
    model = Coll
    template_name = "colls/coll_list.html"

    def get(self, request):
        strval =  request.GET.get("query", False)
        if strval :
            query = Q(title__icontains=strval) 
            query.add(Q(description__icontains=strval), Q.OR)            
            objects = Coll.objects.filter(query).select_related().order_by('-title')
        else :
            objects = Coll.objects.all().order_by('-title')

        favorites = list()
        if request.user.is_authenticated:
            rows = request.user.favorite_colls.values('id')
            favorites = [ row['id'] for row in rows ]

        # calculate the avg rank

        # paginator
        limit=15
        paginator = Paginator(objects, limit)  

        page = request.GET.get('page') 
        try:
            objects = paginator.page(page)  
        except PageNotAnInteger: 
            objects = paginator.page(1)  
        except EmptyPage:  
            objects = paginator.page(paginator.num_pages)

        ctx = {'coll_list' : objects, 'favorites': favorites,'search':strval}
        retval = render(request, self.template_name, ctx)

        return retval


class CollFavView(OwnerListView):
    model = Coll
    template_name = "colls/coll_fav.html"

    def get(self, request):
        favorites = list()
        if request.user.is_authenticated:
            rows = request.user.favorite_colls.values('id')
            favorites = [ row['id'] for row in rows ]
        
        objects = Coll.objects.filter(id__in=favorites).order_by('-title')

        ctx = {'coll_list' : objects, 'favorites': favorites}
        retval = render(request, self.template_name, ctx)

        return retval


class CollDetailView(OwnerDetailView):
    model = Coll
    template_name = "colls/coll_detail.html"
    def get(self, request, pk) :
        x = Coll.objects.get(id=pk)
        comments = Comment.objects.filter(coll=x).order_by('-updated_at')
        comment_form = CommentForm()

        favorites = list()
        if request.user.is_authenticated:
            rows = request.user.favorite_colls.values('id')
            favorites = [ row['id'] for row in rows ]
        
        context = { 'coll' : x, 'comments': comments, 'favorites': favorites, 'comment_form': comment_form }
        return render(request, self.template_name, context)


class CommentCreateView(LoginRequiredMixin, View):
    def post(self, request, pk) :
        coll = get_object_or_404(Coll, id=pk)
        comment = Comment(
            title=request.POST['title'], 
            text=request.POST['text'], 
            rank=request.POST['rank'], 
            owner=request.user, 
            coll=coll)
        comment.save()
        print(comment.__str__)
        return redirect(reverse('colls:coll_detail', args=[pk]))

class CommentDeleteView(OwnerDeleteView):
    model = Comment
    template_name = "colls/coll_comment_delete.html"

    def get_success_url(self):
        coll = self.object.coll
        return reverse('colls:coll_detail', args=[coll.id])


from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator
from django.db.utils import IntegrityError

@method_decorator(csrf_exempt, name='dispatch')
class AddFavoriteView(LoginRequiredMixin, View):
    def post(self, request, pk) :
        print("Add PK",pk)
        t = get_object_or_404(Coll, id=pk)
        fav = Fav(user=request.user, coll=t)
        try:
            fav.save()  # In case of duplicate key
        except IntegrityError as e:
            pass
        return HttpResponse()

@method_decorator(csrf_exempt, name='dispatch')
class DeleteFavoriteView(LoginRequiredMixin, View):
    def post(self, request, pk) :
        print("Delete PK",pk)
        t = get_object_or_404(Coll, id=pk)
        try:
            fav = Fav.objects.get(user=request.user, coll=t).delete()
        except Fav.DoesNotExist as e:
            pass

        return HttpResponse()