from django import forms
from colls.models import Coll, Comment
from django.core.exceptions import ValidationError
from django.core import validators
from colls.humanize import naturalsize

class CommentForm(forms.ModelForm):
    class Meta:
        model = Comment
        fields = ['title', 'text', 'rank'] 